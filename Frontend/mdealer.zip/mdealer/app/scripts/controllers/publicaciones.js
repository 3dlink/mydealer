'use strict';

/**
 * @ngdoc function
 * @name myDealerNetworkApp.controller:AboutCtrl
 * @description
 * # AboutCtrl
 * Controller of the myDealerNetworkApp
 */
angular.module('myDealerNetworkApp')
  .controller('PublicacionesCtrl', function () {
    this.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
