'use strict';

/**
 * @ngdoc function
 * @name myDealerNetworkApp.controller:MainCtrl
 * @description
 * # MainCtrl
 * Controller of the myDealerNetworkApp
 */
angular.module('myDealerNetworkApp')
  .controller('MainCtrl', function () {
    this.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
